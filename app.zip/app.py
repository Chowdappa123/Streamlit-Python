import string
import random
import streamlit as st
import pandas as pd
import numpy as np
import datetime
import subprocess
import os
import uuid
import about
import ydata_profiling
import pandas_profiling
from pandas import DataFrame
import xml.etree.ElementTree as ET
import csv
from faker import Faker
import tkinter as tk

JMETER_PATH = os.environ['JMETER_HOME']
current_time = datetime.datetime.now().strftime("%Y%m%d_%H%M%S%f")[:-3]
faker = Faker()
def generate_csv():
# current_time = datetime.datetime.now().strftime("%Y%m%d_%H%M%S%f")[:-3]
# faker = Faker()
    
 with open("C:\\Users\\mallika.appasani\\apache-jmeter-5.5\\bin\\saptr1.csv", mode="w", newline="") as file:
    writer = csv.writer(file)
    data = ["MSISDN"]
    for line in data:
        writer.writerow(line.split(","))

    for i in range(1, 10):
        start_msisdn = 968104494943
        MSISDN = f"{start_msisdn + i}"

        data1 = [f"{MSISDN}"]
        for line in data1:
            writer.writerow(line.split(","))

def update_jmx():
 # Parse the JMX file
 csv_file_path = 'C:\\Users\\mallika.appasani\\apache-jmeter-5.5\\bin\\saptr1.csv'
 tree = ET.parse('C:\\Users\\mallika.appasani\\apache-jmeter-5.5\\bin\\PTC_VOLTEAPIS.jmx')
 root = tree.getroot()
# Find the CSVDataSet element(s)
 for csv_dataset in root.iter('CSVDataSet'):
# Modify the filename attribute
  csv_dataset.set('filename', csv_file_path)
# Write the modified XML back to the JMX file
 tree.write('C:\\Users\\mallika.appasani\\apache-jmeter-5.5\\bin\\PTC_VOLTEAPIS.jmx')


def main_about():
    st.title('About')
    st.markdown('---')
    #Display About section
    


def pd_profile(filename):
    df = pd.read_csv(JMETER_PATH + '\\bin\\' + filename)
    report = pandas_profiling.ProfileReport(df)
    #st.write(pandas_profiling.__version__)
    random_filename = ''.join(random.choices(string.ascii_uppercase + string.digits, k = 24)) 
    random_filename = random_filename + ".html"
    st.write('Report file name is `%s`' % random_filename + ' . Report is located at ' + JMETER_PATH + '\\bin\\')
    #st.write('You selected `%s`' % selected_filename + '. To execute this test plan, click on Run button as shown below.')
    report.to_file(output_file=random_filename)
    #st.markdown(report)
    return 

def jmeter_execute_load():
    global JMETER_PATH
    #Changing Directory to Root
    #os.chdir('.')
    os.chdir(JMETER_PATH + '\\bin')
    jmeterFileNames = []
    
    # Find only JMeter test plans
    for f in os.listdir("."):
        if f.endswith('.jmx'):
            jmeterFileNames.append(f)
    selected_filename = st.selectbox('Select a file to execute',jmeterFileNames)
    st.write('You selected `%s`' % selected_filename + '. To execute this test plan, click on Run button as shown below.')
    st.info('JMeter Path is ' + JMETER_PATH)
    if st.button('Run'):
        st.info('Execution has been started, you can monitor the stats in the command prompt.')
        jmeter_execute(selected_filename)
    #jmeterfilename = jmeter_execute()
    #st.write('You selected `%s`' % jmeterfilename)

def jmeter_execute(selected_filename):
    global JMETER_PATH
    
    logFileName = "results_" + current_time + ".csv"
    
    st.text('Results file is ' + logFileName)

    os.chdir(JMETER_PATH + '\\bin')
    #st.text('Your curret directory is ' + os.getcwd())
    cmd = "jmeter.bat -n -t " + selected_filename + " -l " + logFileName
    st.text('Executing ' + cmd)
    #os.chdir(".")
    returned_value = os.system(cmd)

    # perform analysis on file_path
    pass

def jmeter_analyze():
    jmeterResults = []
    os.chdir(JMETER_PATH + '\\bin')
    filenames = os.listdir(".")
    # Find only JMeter test results
    for f in os.listdir("."):
        if f.endswith('.csv'):
            jmeterResults.append(f)
    selected_filename = st.selectbox('Select a file to analyze (supports only CSV extension)', jmeterResults)
    return os.path.join(selected_filename)
def jmeter_recommend():

    # Set the page title
    # st.title("JMeter Throughput Recommendation")

    # Add a file uploader for JMeter results CSV
    uploaded_file = st.file_uploader("Upload JMeter results CSV", type="csv")

     # If a file is uploaded
    
    if uploaded_file is not None:
    # Load the CSV into a pandas dataframe
        df = pd.read_csv(uploaded_file)
        # Set the page title
        # st.title("JMeter Throughput Recommendations")
        # st.write("Throughput Recommendation:")
        st.markdown("<h1 style='text-align: center; color: orange; font-size: 40px;'>Throughput Recommendation</h1>", unsafe_allow_html=True)
        # Calculate the throughput recommendation
        elapsed_sum = df['elapsed'].sum()
        request_count = len(df)
        throughput = request_count / elapsed_sum * 1000
        throughput_data = df.groupby(['label'])['elapsed'].agg(['count', 'mean'])
        throughput_data['throughput'] = throughput_data['count'] / elapsed_sum * 1000
        throughput_data = throughput_data[['throughput', 'count', 'mean']].reset_index()
        throughput_data.columns = ['Request URL', 'Throughput (req/s)', 'Request Count', 'Mean Response Time (ms)']
        # Add a message column to the table based on the response time
        throughput_data['Message'] = ['Response time > 500 ms,it is not acceptable' if mean_time > 500 else 'Response time <= 500 ms' for mean_time in throughput_data['Mean Response Time (ms)']]
        st.table(throughput_data)
        # Display the throughput recommendation
        st.write(f"Based on your JMeter results, the recommended throughput is: {throughput:.2f} requests/second")
        # Define the recommended latency threshold in milliseconds
        RECOMMENDED_LATENCY = 100
        # Set the page title
        # st.title("JMeter Latency Recommendations")
        # Calculate the 90th percentile latency for all requests
        latency = df['Latency'].quantile(0.90)
        # Create a table that shows the latency for each request URL
        # st.write("Latency Recommendation")
        st.markdown("<h1 style='text-align: center; color: orange; font-size: 40px;'>Latency Recommendation</h1>", unsafe_allow_html=True)
        latency_data = df.groupby(['label'])['Latency'].agg(['count', 'mean', 'max', 'min', 'std'])
        latency_data = latency_data[['count', 'mean', 'max', 'min', 'std']].reset_index()
        latency_data.columns = ['Request URL', 'Request Count', 'Mean Latency (ms)', 'Max Latency (ms)', 'Min Latency (ms)', 'Standard Deviation (ms)']
        # Add a message column to the table based on the latency
        latency_data['Message'] = ['Latency > recommended' if mean_latency > RECOMMENDED_LATENCY else 'Latency <= recommended' for mean_latency in latency_data['Mean Latency (ms)']]
        # Display the resulting table
        st.table(latency_data)
        # Display the recommended latency
        st.write(f"Based on your JMeter results, the recommended latency is: {RECOMMENDED_LATENCY:.2f} ms")


        # Show a warning if the recommended latency is exceeded
        if latency > RECOMMENDED_LATENCY:
            st.warning("The overall latency exceeds the recommended threshold.")
        else:
            st.success("The overall latency is within the recommended threshold.")

            


def main():

    menu_list = ['Generate csv','Update jmx','Execute JMeter Test Plan','Analyze JMeter Test Results', 'Recommendations','Home']
    # Display options in Sidebar
    st.sidebar.title('Navigation')
    menu_sel = st.sidebar.radio('', menu_list, index=2, key=None)

    # Display text in Sidebar
    about.display_sidebar()

    # Selecting About Menu
    if menu_sel == 'Home':
        about.display_about()

    # Selecting Execute Menu
    if menu_sel == 'Execute JMeter Test Plan':
    #jmeter_run = st.radio('Select',('Default','Execute','Analyze'))
    #if jmeter_run == 'Execute':
        st.title('Execute JMeter Test Plan')
        jmeter_execute_load()


    #if jmeter_run == 'Analyze':
    if menu_sel == 'Analyze JMeter Test Results':
        st.title('Analyze JMeter Test Results')

        filename = jmeter_analyze()
        st.write('You selected `%s`' % filename)
         #DATA_URL = ('C:\\Users\\Navee\\OneDrive\\Documents\\Tools\\apache-jmeter-5.2\\bin\\Run2.csv')
        DATA_URL = filename

        
        st.markdown('')
        # Show Graphs Checkbox
        show_graphs = st.checkbox('Show Graphs')

        # Show Profiling Report
        profile_report = st.button('Generate Profiling Report')
       
        # Generate Profiling Report

        if profile_report:
            st.write('Generating Report for ', filename)
            pd_profile(filename)


        st.title('Apache JMeter Load Test Results')
        data = pd.read_csv(DATA_URL)
        
        #Display Start Time
        startTime = data['timeStamp'].iloc[0]/1000
        startTime = datetime.datetime.fromtimestamp(startTime).strftime('%Y-%m-%d %H:%M:%S')
        st.write('Start Time ', startTime)

        endTime = data['timeStamp'].iloc[-1]/1000
        endTime = datetime.datetime.fromtimestamp(endTime).strftime('%Y-%m-%d %H:%M:%S')
        st.write('End Time ', endTime)

        FMT = '%Y-%m-%d %H:%M:%S'
        delta = datetime.datetime.strptime(endTime, FMT) - datetime.datetime.strptime(startTime, FMT)

        st.write('Total duration of the test (HH:MM:SS) is ', delta)

        st.subheader('Summary Report - Response Time')
        st.write(data.groupby('label')['elapsed'].describe(percentiles=[0.75,0.95,0.99]))

        st.subheader('Error Count')
        errCount = data.groupby(['label','responseCode'])['responseCode'].count()
        st.write(errCount)

        if show_graphs:
            chart_data = pd.DataFrame(data,columns=['timeStamp','Latency','label','responseCode','elapsed','Connect','bytes'])

            st.subheader("Graph between Timestamp and Latency")
                
            st.vega_lite_chart(chart_data, {
                "mark": {"type": "bar", "color": "maroon"},    
                "selection": {
                    "grid": {
                    "type": "interval", "bind": "scales"
                    }
                }, 
                'encoding': {
                    "tooltip": [
                {"field": "timeStamp", "type": "temporal"},
                {"field": "label", "type": "nominal"},
                {"field": "Latency", "type": "quantitative"}
                ],
                'x': {'field': 'timeStamp', 'type': 'temporal'},
                'y': {'field': 'Latency', 'type': 'quantitative'},
                },
                })

            st.subheader("Graph between Timestamp and Response Code")
            st.vega_lite_chart(chart_data, {
                "mark": {"type": "bar", "color": "aqua"},    
                "selection": {
                    "grid": {
                    "type": "interval", "bind": "scales"
                    }
                }, 
                'encoding': {
                    "tooltip": [
                {"field": "timeStamp", "type": "temporal"},
                {"field": "label", "type": "nominal"},
                {"field": "responseCode", "type": "quantitative"}
                ],
                'x': {'field': 'timeStamp', 'type': 'temporal'},
                'y': {'field': 'responseCode', 'type': 'quantitative'},
                },
                })

            st.subheader("Graph between Timestamp and Response Time")
            st.vega_lite_chart(chart_data, {
                "mark": {"type": "bar", "color": "orange"},    
                "selection": {
                    "grid": {
                    "type": "interval", "bind": "scales"
                    }
                }, 
                'encoding': {
                    "tooltip": [
                {"field": "timeStamp", "type": "temporal"},
                {"field": "label", "type": "nominal"},
                {"field": "elapsed", "type": "quantitative"}
                ],
                'x': {'field': 'timeStamp', 'type': 'temporal'},
                'y': {'field': 'elapsed', 'type': 'quantitative'},
                },
                })

            st.subheader("Graph between Timestamp and Connect Time")
            st.vega_lite_chart(chart_data, {
                "mark": {"type": "bar", "color": "darkgreen"},    
                "selection": {
                    "grid": {
                    "type": "interval", "bind": "scales"
                    }
                }, 
                'encoding': {
                    "tooltip": [
                {"field": "timeStamp", "type": "temporal"},
                {"field": "label", "type": "nominal"},
                {"field": "Connect", "type": "quantitative"}
                ],
                'x': {'field': 'timeStamp', 'type': 'temporal'},
                'y': {'field': 'Connect', 'type': 'quantitative'},
                },
                })

            st.subheader("Graph between Timestamp and bytes")
            st.vega_lite_chart(chart_data, {
                "mark": {"type": "bar", "color": "darkblue"},    
                "selection": {
                    "grid": {
                    "type": "interval", "bind": "scales"
                    }
                }, 
                'encoding': {
                    "tooltip": [
                {"field": "timeStamp", "type": "temporal"},
                {"field": "label", "type": "nominal"},
                {"field": "bytes", "type": "quantitative"}
                ],
                'x': {'field': 'timeStamp', 'type': 'temporal'},
                'y': {'field': 'bytes', 'type': 'quantitative'},
                },
                })

            st.subheader("Graph between Timestamp and Response Time - Line Chart")
            st.vega_lite_chart(chart_data, {
            "mark": "line",
        "encoding": {
            "tooltip": [
                {"field": "timeStamp", "type": "temporal"},
                {"field": "label", "type": "nominal"},
                {"field": "elapsed", "type": "quantitative"}
                ],
            "x": {"field": "timeStamp", "type": "temporal"},
            "y": {"field": "elapsed", "type": "quantitative"},
            "color": {"field": "label", "type": "nominal"}
        },
                })
        
            st.subheader("Graph between Timestamp and Response Time - Bar Chart")
            st.vega_lite_chart(chart_data, {
            "mark": "bar",
        "encoding": {
            "tooltip": [
                {"field": "timeStamp", "type": "temporal"},
                {"field": "label", "type": "nominal"},
                {"field": "elapsed", "type": "quantitative"}
                ],
            "x": {"field": "timeStamp", "type": "temporal"},
            "y": {"field": "elapsed", "type": "quantitative"},
            "color": {"field": "label", "type": "nominal"}
        },
                })

            st.subheader("Histogram")
            st.vega_lite_chart(chart_data, {
                "transform": [{
                "filter": {"and": [
                {"field": "timeStamp", "valid": True},
                {"field": "elapsed", "valid": True}
                ]}
            }],
            "mark": "rect",
            "width": 300,
            "height": 200,
            "encoding": {
                "x": {
                "field": "timeStamp",
                "type": "temporal"
                },
                "y": {
                "field": "elapsed",
                "type": "quantitative"
                },
                "color": {
                "aggregate": "count",
                "type": "quantitative"
                }
            },
            "config": {
                "view": {
                "stroke": "transparent"
                }
            }
                    })

            st.subheader("Histogram")
            st.vega_lite_chart(chart_data, {
                "transform": [{
                "filter": {"and": [
                {"field": "timeStamp", "valid": True},
                {"field": "Connect", "valid": True}
                ]}
            }],
            "mark": "rect",
            "width": 300,
            "height": 200,
            "encoding": {
                "x": {
                "field": "timeStamp",
                "type": "temporal"
                },
                "y": {
                "field": "Connect",
                "type": "quantitative"
                },
                "color": {
                "aggregate": "count",
                "type": "quantitative"
                }
            },
            "config": {
                "view": {
                "stroke": "transparent"
                }
            }
                    })

            st.subheader("Scatter Plot between Timestamp and Response Time")
            st.vega_lite_chart(chart_data, {
                    
                "selection": {
                "grid": {
                "type": "interval", "bind": "scales"
                }
            },
            "mark": "circle",
            "encoding": {
                "tooltip": [
                    {"field": "timeStamp", "type": "temporal"},
                    {"field": "label", "type": "nominal"},
                    {"field": "elapsed", "type": "quantitative"}
                    ],
                "x": {
                "field": "timeStamp", "type": "temporal"    },
                "y": {
                "field": "elapsed", "type": "quantitative"    },
                "size": {"field": "label", "type": "nominal"}
            },
                    })
    if menu_sel=='Recommendations' :
        st.title('Recommendations')
        jmeter_recommend()
    if menu_sel=='Generate csv' :
        st.title('Generate csv')
        st.write("csv file is generated")
        generate_csv()
    if menu_sel=='Update jmx' :
        st.title('Update jmx')
        st.write("jmx is updated")
        update_jmx()
    
if __name__== "__main__":
    main()